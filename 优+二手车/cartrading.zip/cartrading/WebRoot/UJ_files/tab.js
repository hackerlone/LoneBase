$(function(){
  /*车辆详情页了解更多*/
  $("#carMsg").hover(
  	function() {
      $(this).addClass("active");
      $("#msgMore").show();
    },
    function() {
      $(this).removeClass("active");
      $("#msgMore").hide();
    });
  $(".day-pic").hover(
  	function() {
      $("#msgMore").show().css({"top":"90px","right":"5px"});
    },
    function() {
      $("#msgMore").hide();
    });

  /*车辆详情页分享到*/
  $("#sMore").hover(
  	function() {
      $("#shareCar").show();
    },
    function() {
      $("#shareCar").hide();
    })


	var tabs = function(e1, e2, e3){
	  var e1 = $('a', e1);
	  var e2 = $(e2);
	  e1.click(function(){
	  	$('.error').remove();
	    if(!$(this).hasClass('active')){
	      e1.removeClass('active');
	      $(this).addClass('active');
	      var idx = e1.index(this);
	      e2.fadeOut(0);
	      $(e2[idx]).fadeIn(0);
	      $(e3).attr('href',$(this).attr('href'));
	    }
	  });
	  e1.click(function(){
	    return false;
	  })
	}
	// //横排，竖排显示方式
	// tabs('.cut', '.car-box');
	tabs('.rec-tit', '.slideRec');
	tabs('.con-nav', '.TabCon');
	tabs('.logintab', '.logincon');
	// //列表页图片中间间距
	// $(".car-box .car-crs:even").css("margin-right","16px");
	// $(".car-box .car-vtc:last").css("border-bottom","1px solid #d9d9d9");
})


