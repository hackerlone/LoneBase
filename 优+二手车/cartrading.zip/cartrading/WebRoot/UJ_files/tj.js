(function () {
    var params = {};
    //Document对象数据
    if(document) {
        params.domain = document.domain || ''; 
        params.url = document.URL || ''; 
        params.title = document.title || ''; 
        params.referrer = document.referrer || ''; 
    }   
    //Window对象数据
    if(window && window.screen) {
        params.sh = window.screen.height || 0;
        params.sw = window.screen.width || 0;
        params.cd = window.screen.colorDepth || 0;
    }   
    //navigator对象数据
    if(navigator) {
        params.lang = navigator.language || ''; 
    }    
    //拼接参数串
    var args = ''; 
    for(var i in params) {
        if(args != '') {
            args += '&';
        }   
        args += i + '=' + encodeURIComponent(params[i]);
    }
	var img = new Image();
	var rnd_id = "_img_" + Math.random();
	window[rnd_id] = img; // 全局变量引用
	img.onload = img.onerror = function () {
		window[rnd_id] = null; // 删除全局变量引用
	}
	img.src = "http://tj.xin.com/w.gif?"+ args +'&s=' + Math.random();
})();