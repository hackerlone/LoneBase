$(document).ready(function() {

	$("#uploadBtn").click(function() {
		var file=document.getElementById("file");
		if(file.length>=99||file.fileSize>=1024*1024){
			alert("总文件名过长,上传失败！");
		}else{
		 ajaxFileUpload();
		}
	});
});
function ajaxFileUpload() {
	var elementIds = [ "file" ]; //flagΪid��name������

	$.ajaxFileUpload( {
		url : 'upload_exec',
		type : 'post',
		secureuri : false, //һ������Ϊfalse
		fileElementId : 'file', // �ϴ��ļ���id��name������
		dataType : 'text', //����ֵ���ͣ�һ������Ϊjson��application/json
		elementIds : elementIds, //���ݲ��������
		success : function(data, status) {
		$data = $(data);
		$("#headimg").attr("src","upload/"+$data.text().substring(0, 24));
		$("#headimg1").attr("src","upload/"+$data.text().substring(25, 49));
		$("#headimg2").attr("src","upload/"+$data.text().substring(50, 74));
		$("#headimg3").attr("src","upload/"+$data.text().substring(75, 99));
		$("input[name='car.image']").val($data.text());
		$("input[name='user.UImg']").val($data.text());
		},
		error : function(data, status, e) {
			alert(e);
		}
	});
	//return false;
}