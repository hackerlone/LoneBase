var GJ = window.GJ || {}, __GJ_CONFIG__ = window.__GJ_CONFIG__ || {};
(function() {
	var b = window, a = b.document;
	if (b.__GJ_LOADED__) {
		return
	}
	b.__GJ_LOADED__ = true;
	GJ.config = {
		debug : false,
		rootDir : "",
		addVersion : false,
		useCombine : false,
		cookieDomain : "ganji.com",
		documentDomain : "ganji.com",
		iframeProxyUrl : "/iframeproxy.html",
		defaultServer : "sta.ganji.com",
		servers : [ "sta.ganjistatic1.com" ],
		fileVersions : {},
		fileCombines : {},
		fileCodes : {
			autocomplete : "js/util/autocomplete/autocomplete.js",
			jquery : "js/util/jquery/jquery-1.7.2.js",
			jquery_ui : "js/util/jquery/jquery.ui.js",
			util : "js/util/ganji/util.cmb.js",
			json : "js/util/json/json.js",
			log_tracker : "js/util/log_tracker/log_tracker_simple.js",
			iframe : [ "jquery", "js/util/iframe/iframe.js" ],
			panel : [ "js/util/panel/panel.css", "iframe",
					"js/util/dragdrop/dragdrop.js", "js/util/panel/panel.js" ],
			flash : [ "jquery", "js/util/swfobject/swfobject-2.2.js",
					"js/util/swfobject/swfloader.js" ],
			talk_to_parent : [ "jquery", "js/util/window_name/window_name.js",
					"js/util/iframe/talk_to_parent.js" ]
		},
		cdnFiles : {
			"tool/webim/js/webim.cmb.js" : 1,
			"tool/webim_v2/js/webim.cmb.js" : 1
		}
	};
	GJ.loadedFiles = {};
	GJ.tralog = function(d, e) {
		var c = new Image();
		if (GJ.config.debug) {
			return
		}
		c.src = "http://tralog.ganji.com/sta/log.gif?"
				+ [ "t=" + d, "m=" + e ].join("&")
	};
	(function() {
		var d = {
			"undefined" : "undefined",
			number : "number",
			"boolean" : "boolean",
			string : "string",
			"[object Function]" : "function",
			"[object RegExp]" : "regexp",
			"[object Array]" : "array",
			"[object Date]" : "date",
			"[object Error]" : "error"
		}, c = {
			isArray : function(e) {
				return c.typeOf(e) === "array"
			},
			isBoolean : function(e) {
				return typeof e === "boolean"
			},
			isFunction : function(e) {
				return c.typeOf(e) === "function"
			},
			isDate : function(e) {
				return c.typeOf(e) === "date"
			},
			isNull : function(e) {
				return e === null
			},
			isNumber : function(e) {
				return typeof e === "number" && isFinite(e)
			},
			isObject : function(f, e) {
				return (f && (typeof f === "object" || (!e && c.isFunction(f)))) || false
			},
			isString : function(e) {
				return typeof e === "string"
			},
			isUndefined : function(e) {
				return typeof e === "undefined"
			},
			isValue : function(f) {
				var e = c.typeOf(f);
				switch (e) {
				case "number":
					return isFinite(f);
				case "null":
				case "undefined":
					return false;
				default:
					return !!(e)
				}
			},
			typeOf : function(e) {
				return d[typeof e] || d[Object.prototype.toString.call(e)]
						|| (e ? "object" : "null")
			}
		};
		GJ.mix = function(h, g, f, j) {
			if (c.isObject(h) && c.isObject(g)) {
				for ( var e in g) {
					if (g.hasOwnProperty(e)) {
						if (!(e in h)) {
							h[e] = g[e]
						} else {
							if (f) {
								if (j && c.isObject(h[e], true)
										&& c.isObject(g[e], true)) {
									GJ.mix(h[e], g[e], f, j)
								} else {
									h[e] = g[e]
								}
							}
						}
					}
				}
			}
			return h
		};
		GJ.mix(GJ, c, true)
	})();
	GJ.each = function(f, c) {
		if (GJ.isFunction(c)) {
			var d, g, e;
			if (GJ.isArray(f)) {
				for (d = 0, g = f.length; d < g; d++) {
					e = c(f[d], d);
					if (e === false) {
						break
					}
				}
			} else {
				if (GJ.isObject(f)) {
					for (d in f) {
						if (f.hasOwnProperty(d)) {
							e = c(f[d], d);
							if (e === false) {
								break
							}
						}
					}
				}
			}
		}
	};
	GJ.map = function(d, c) {
		var e = [];
		GJ.each(d, function(f, g) {
			e.push(c(f, g))
		});
		return e
	};
	GJ.inArray = function(d, c) {
		var e = -1;
		GJ.each(c, function(f, g) {
			if (f === d) {
				e = g;
				return false
			}
		});
		return e
	};
	GJ.setConfig = function(e) {
		var d = arguments, c = GJ.config;
		if (d.length == 2) {
			var f = {};
			f[d[0]] = d[1];
			GJ.setConfig(f)
		} else {
			GJ.each(e, function(h, g) {
				if (GJ.isObject(c[g])) {
					GJ.mix(c[g], h, true)
				} else {
					c[g] = h
				}
			})
		}
		c.rootDir = c.debug ? "src/" : "public/";
		if (c.debug) {
			c.useCombine = false
		}
	};
	(function() {
		if (!window.__GJ_PACK_CONFIG__) {
			return
		}
		var c = [], f = window.__GJ_PACK_CONFIG__, d = function(h) {
			if (GJ.isNumber(h)) {
				return c[h]
			} else {
				var g = [];
				GJ.each(h, function(j, i) {
					g.push(c[h[i]])
				});
				return g
			}
		}, e = function(i, g) {
			var h = {};
			GJ.each(i, function(l, j) {
				if (g == 1) {
					h[c[j]] = l
				} else {
					if (g == 2) {
						h[c[j]] = d(l)
					} else {
						if (g == 3) {
							h[j] = d(l)
						}
					}
				}
			});
			return h
		};
		GJ.each(f.words, function(h, g) {
			var i = h.split("|");
			c[g] = i[1] ? c[i[0]] + i[1] : i[0]
		});
		f.fileVersions = e(f.fileVersions, 1);
		f.fileCombines = e(f.fileCombines, 2);
		f.fileCodes = e(f.fileCodes, 3);
		delete f.words;
		GJ.setConfig(f)
	})();
	GJ.setConfig(__GJ_CONFIG__);
	GJ.rand = function(d, c) {
		return parseInt(Math.random() * (c - d + 1) + d)
	};
	(function() {
		var c = 0;
		GJ.getRandServer = function() {
			var d = GJ.config.servers;
			return d[c++ % d.length]
		}
	})();
	GJ.namespace = function() {
		var c = arguments, l = null, g, m, f, e, h;
		for (g = 0, m = c.length; g < m; g++) {
			h = c[g].split(".");
			l = GJ;
			for (f = (h[0] == "GJ") ? 1 : 0, e = h.length; f < e; f++) {
				l[h[f]] = l[h[f]] || {};
				l = l[h[f]]
			}
		}
		return l
	};
	GJ.namespace("util", "apps", "widget", "common");
	(function() {
		var c = function(e, f) {
			GJ.each(f, function(h, g) {
				if (GJ.isFunction(h)) {
					e[g] = function(i) {
						return function() {
							return i.apply(f, arguments)
						}
					}(h)
				}
			})
		}, d = {
			"**SYS_FROM_INSIDE**" : true
		};
		GJ.f = function(h, e) {
			if (arguments.length === 1) {
				e = h;
				h = {}
			}
			var i = h.__const || {}, f = h.__extends || null;
			function g(t, j, m) {
				var q = !m || !m["**SYS_FROM_INSIDE**"], p = q ? {} : t, r = q ? {}
						: j, s = null;
				if (f) {
					if (GJ.isArray(f)) {
						for ( var l = 0, k = f.length; l < k; l++) {
							if (GJ.isFunction(f[l])) {
								f[l](p, r, d)
							}
						}
					} else {
						if (GJ.isFunction(f)) {
							f(p, r, d)
						}
					}
					s = {};
					c(s, p)
				}
				if (GJ.isFunction(e)) {
					var o = e.apply(p, [ r, s ]);
					if (GJ.isObject(o)) {
						GJ.mix(p, o, true)
					}
				}
				if (q) {
					if (p.__construct) {
						p.__construct.apply(p, arguments);
						delete p.__construct
					}
				}
				return p
			}
			if (h.__static) {
				GJ.mix(g, h.__static, true)
			}
			g.getConst = function(j) {
				return i[j] || null
			};
			return g
		}
	})();
	GJ.extend = function(g, e, c, i) {
		if (!e || !g) {
			alert("extend failed, verify dependencies")
		}
		var h = e.prototype, f = function() {
		};
		f.prototype = h;
		var d = new f();
		g.prototype = d;
		d.constructor = g;
		g.superclass = h;
		if (e != Object && h.constructor == Object.prototype.constructor) {
			h.constructor = e
		}
		if (c) {
			GJ.mix(d, c, true)
		}
		if (i) {
			GJ.mix(g, i, true)
		}
	};
	GJ.createClass = function() {
		var d = arguments, c = d.length;
		function e() {
			this.__inited__ = false;
			if (e.superclass) {
				e.superclass.constructor.apply(this, arguments)
			}
			if (!this.__inited__ && this.init && GJ.isFunction(this.init)) {
				var f = this.init.apply(this, arguments);
				this.__inited__ = true;
				if (GJ.isObject(f)) {
					return f
				}
			}
		}
		if (GJ.isFunction(d[0])) {
			GJ.extend(e, d[0], d[1] || null, d[2] || null)
		} else {
			if (d[0]) {
				e.prototype = d[0]
			}
			if (d[1]) {
				GJ.mix(e, d[1], true)
			}
		}
		return e
	};
	(function() {
		var d = 0;
		GJ.guid = function(f) {
			var e = new Date().getTime() + "" + Math.random();
			return (f ? f : "guid_") + d++ + "_" + e.replace(/\./g, "_")
		};
		var c = {};
		GJ.getCache = function(e) {
			return !GJ.isUndefined(c[e]) ? c[e] : null
		};
		GJ.setCache = function(f, e) {
			if (arguments.length == 1) {
				e = f;
				f = GJ.guid()
			}
			c[f] = e;
			return f
		};
		GJ.removeCache = function(e) {
			if (!GJ.isUndefined(c[e])) {
				delete c[e]
			}
		};
		GJ.clearCache = function() {
			c = {}
		}
	})();
	GJ.getCookie = function(d) {
		var e = document, f = null, c;
		if (e.cookie) {
			c = e.cookie.match(new RegExp("(^| )" + d + "=([^;]*)(;|$)"));
			if (c != null) {
				f = decodeURIComponent(c[2])
			}
		}
		return f
	};
	GJ.setCookie = function(d, h, c, i, g, e) {
		if (GJ.isUndefined(document.cookie)) {
			return false
		}
		c = !GJ.isNumber(c) ? 0 : parseInt(c);
		if (c < 0) {
			h = ""
		}
		var f = new Date();
		f.setTime(f.getTime() + 1000 * c);
		document.cookie = d + "=" + encodeURIComponent(h)
				+ ((c) ? "; expires=" + f.toGMTString() : "") + "; path="
				+ (i || "/") + "; domain=" + (g || GJ.config.cookieDomain)
				+ ((e) ? "; secure" : "");
		return true
	};
	GJ.removeCookie = function(c, e, d) {
		return GJ.setCookie(c, "", -1, e, d)
	};
	GJ.error = function(c) {
		throw new Error(c)
	};
	GJ.log = function(c) {
		if (typeof console != "undefined" && console.log) {
			console.log(c)
		} else {
			if (typeof opera != "undefined") {
				opera.postError(c)
			}
		}
	};
	GJ.later = function(e, c, d) {
		c = c || 0;
		var f = null, g = function() {
			f = f || (d) ? setInterval(e, c) : setTimeout(e, c)
		};
		g();
		return {
			run : g,
			cancel : function() {
				if (f) {
					if (d) {
						clearInterval(f)
					} else {
						clearTimeout(f)
					}
					f = null
				}
			}
		}
	};
	GJ.waiter = function(c, i, g, e) {
		if (!GJ.isFunction(c) || !GJ.isFunction(i)) {
			return
		}
		var d = g || 100, f = 0, e = (e || 10) * 1000, h = function(k, j) {
			if (k()) {
				j();
				return
			}
			f += d;
			if (!e || f < e) {
				GJ.later(function() {
					h(k, j)
				}, d)
			}
		};
		h(c, i)
	};
	GJ.addEvent = function(e, d, c) {
		if (e.addEventListener) {
			e.addEventListener(d, c, false)
		} else {
			if (e.attachEvent) {
				e.attachEvent("on" + d, c)
			}
		}
	};
	GJ.removeEvent = function(e, d, c) {
		if (e.removeEventListener) {
			e.removeEventListener(d, c, false)
		} else {
			if (e.detachEvent) {
				e.detachEvent("on" + d, c)
			}
		}
	};
	(function() {
		var j = window, i = document, f = false, h = [], d, g = false, e = function() {
			if (g) {
				return
			}
			g = true;
			e = Function.prototype;
			f = true;
			for ( var k = 0; k < h.length; k++) {
				h[k]()
			}
			h.length = 0;
			g = false
		};
		if ("readyState" in i) {
			d = i.readyState;
			f = d == "complete"
					|| (~navigator.userAgent.indexOf("AppleWebKit/") && (d == "loaded" || d == "interactive"))
		} else {
			f = !!i.body
		}
		if (!f) {
			if (j.addEventListener) {
				i.addEventListener("DOMContentLoaded", e, false)
			} else {
				i.attachEvent("onreadystatechange", function() {
					if (i.readyState == "complete") {
						e()
					}
				});
				if (i.documentElement.doScroll && j === top) {
					(function c() {
						if (f) {
							return
						}
						try {
							i.documentElement.doScroll("left")
						} catch (k) {
							setTimeout(c, 1);
							return
						}
						e()
					}())
				}
			}
			GJ.addEvent(j, "load", e)
		}
		GJ.onDomReady = function(l, k) {
			if (f) {
				l.call(k);
				return
			}
			h.push(function() {
				l.call(k)
			})
		}
	})();
	(function() {
		GJ.errorStack = [];
		var e = !GJ.config.debug && parseInt(Math.random() * 51) === 1;
		var d = 0;
		GJ.wrap = function(h, g) {
			if (typeof g === "function" && /^function/.test(g.toString())) {
				return h(g)
			}
			return g
		};
		GJ.guard = function(h, g) {
			return function() {
				try {
					return h.apply(this, arguments)
				} catch (j) {
					try {
						GJ.errorStack.push({
							type : g || "GJ_GUARD",
							message : j.message || j.toString(),
							stack : j.stack,
							fn : h.toString().substr(0, 200)
						})
					} catch (i) {
					}
					throw j
				}
			}
		};
		GJ.goTry = function(h, g) {
			return GJ.guard(g, h)
		};
		var f;
		GJ.errorManager = {
			send : function(i, h, g) {
				GJ.errorStack.push({
					type : g,
					message : i,
					loc : h
				});
				clearTimeout(f);
				f = setTimeout(c, 3000)
			}
		};
		function c() {
			if (!e) {
				return
			}
			if (d === GJ.errorStack.length) {
				return
			}
			GJ
					.use(
							"jquery",
							function(g) {
								d = GJ.errorStack.length;
								g
										.ajax({
											url : "/jslogs.php",
											type : "POST",
											data : {
												data : GJ
														.jsonEncode({
															stack : GJ.errorStack,
															url : window.location.href,
															referrer : document.referrer
														})
											},
											error : function() {
												GJ
														.use(
																"log_tracker",
																function() {
																	GJ.LogTracker
																			.trackEvent("javascript@atype=view@LOC="
																					+ encodeURIComponent(window.location.href)
																					+ "@ERR="
																					+ encodeURIComponent("jslogs interface is not reachable!")
																					+ "@TYPE="
																					+ encodeURIComponent("JSLOG_NOT_REACHABLE"))
																})
											}
										})
							})
		}
	})();
	+function() {
		GJ.Deferred = function() {
			var f = "pending";
			var e = {
				done : [],
				fail : [],
				always : []
			};
			var d = [];
			function c(i, h) {
				if (typeof h === "function") {
					if (f === i || (i === "always" && f !== "pending")) {
						setTimeout(function() {
							h.apply({}, d)
						}, 0)
					} else {
						e[i].push(h)
					}
				} else {
					if (f === "pending") {
						f = i;
						var j = e[i];
						var g = e.always;
						while ((h = j.shift()) || (h = g.shift())) {
							setTimeout((function(k) {
								return function() {
									k.apply({}, d)
								}
							})(h), 0)
						}
					}
				}
			}
			return {
				state : function() {
					return f
				},
				done : function(g) {
					if (typeof g === "function") {
						c("done", g)
					} else {
						d = [].slice.call(arguments);
						c("done")
					}
					return this
				},
				fail : function(g) {
					if (typeof g === "function") {
						c("fail", g)
					} else {
						d = [].slice.call(arguments);
						c("fail")
					}
					return this
				},
				always : function(g) {
					if (typeof g === "function") {
						c("always", g)
					}
					return this
				},
				promise : function() {
					return {
						done : function(g) {
							if (typeof g === "function") {
								c("done", g)
							}
							return this
						},
						fail : function(g) {
							if (typeof g === "function") {
								c("fail", g)
							}
							return this
						},
						always : function(g) {
							if (typeof g === "function") {
								c("always", g)
							}
							return this
						},
						state : function() {
							return f
						}
					}
				}
			}
		};
		GJ.when = function() {
			var d = GJ.Deferred(), g = [].slice.call(arguments), c = g.length, f = 0;
			if (!c) {
				return d.done().promise()
			}
			for ( var e = g.length - 1; e >= 0; e--) {
				g[e].fail(function() {
					d.fail()
				}).done(function() {
					if (++f === c) {
						d.done()
					}
				})
			}
			return d.promise()
		}
	}();
	+function() {
		var v = document.getElementsByTagName("head")[0], h = GJ.config;
		var l = h.fileVersions, q = h.fileCodes, d = h.fileCombines;
		var r = GJ.config.debug ? true : false;
		var z = {};
		var f = [];
		var p = +new Date;
		GJ.defers = z;
		GJ.eventList = f;
		var g = {
			ERROR : -2,
			FAILED : -1,
			FETCHING : 1,
			FETCHED : 2,
			SAVED : 3,
			READY : 4,
			COMPILING : 5,
			PAUSE : 6,
			COMPILED : 7
		};
		var k = function(B) {
			B = k.resolve(B)[0];
			if (k.cache[B] && k.cache[B].status === g.COMPILED) {
				return k.cache[B].exports
			} else {
				throw new Error(B + "尚未加载")
			}
		};
		k.resolve = function(C) {
			var B = [];
			if (q[C]) {
				if (typeof q[C] === "string") {
					q[C] = [ q[C] ]
				}
				GJ.each(q[C], function(D) {
					GJ.each(k.resolve(D), function(E) {
						B.push(E)
					})
				})
			} else {
				B.push(C)
			}
			return B
		};
		k.cache = {};
		GJ.Module = {
			STATUS : g,
			cache : k.cache,
			fileLoaders : {
				".js" : m,
				".css" : o
			},
			find : function(B) {
				return k.cache[k.resolve(B)]
			}
		};
		var u = function(D, F) {
			var E = D.toLowerCase();
			if (E.indexOf("http:") === 0 || E.indexOf("https:") === 0) {
				return D
			}
			if (D.indexOf("./") === 0 || D.indexOf("../") === 0) {
				var G = window.location, C = (G.port ? ":" + G.port : "");
				return G.protocol + "//" + G.host + C + "/" + D
			} else {
				if (!F) {
					if (h.cdnFiles[D]) {
						F = "http://stacdn201.ganjistatic1.com"
					} else {
						F = GJ.config.defaultServer
					}
				}
				if (F.indexOf("http") !== 0) {
					F = "http://" + F
				}
				var B = n(D);
				return F
						+ "/"
						+ h.rootDir
						+ D.replace(/(\.(js|css|html?|swf|gif|png|jpe?g))$/i,
								".__" + n(D) + "__$1")
			}
		};
		var e = new Date();
		var t = new Date(e.getFullYear(), e.getMonth(), e.getDate(), 18, 21, 0)
				.getTime();
		var n = function(D) {
			var C = new Date().getTime();
			var B;
			if (h.fileVersions) {
				B = h.fileVersions[D];
				if (!B) {
					if (GJ.config.defaultVersion) {
						B = GJ.config.defaultVersion
					} else {
						if (C < t) {
							C = t - 24 * 3600 * 1000
						} else {
							C = t
						}
						B = parseInt(C / 1000, 10)
					}
				}
			}
			return B
		};
		GJ.getFormatUrl = function(D, B) {
			var E = k.resolve(D), C = [];
			var C = GJ.map(E, function(F) {
				return u(F, B)
			});
			return C.length === 1 ? C[0] : C
		};
		GJ.require = function(B, D) {
			var E = document;
			var F = w(B);
			var C = [];
			if (r) {
				GJ.each(F, function(G) {
					if (d[G.uri]) {
						GJ.each(w(d[G.uri]), function(H) {
							C.push(H)
						})
					} else {
						C.push(G)
					}
				})
			} else {
				C = F
			}
			GJ.each(C, function(H) {
				var G = H.uri;
				H.status = g.FETCHING;
				if (GJ.isFunction(D)) {
					z[H.id].fail(D)
				}
				if (/\.css$/i.test(G)) {
					E.write(unescape("%3Clink href='" + u(G)
							+ "' type='text/css' rel='stylesheet' /%3E"))
				} else {
					E.write(unescape("%3Cscript src='" + u(G)
							+ "' type='text/javascript'%3E%3C/script%3E"))
				}
			})
		};
		GJ.use = function(E, D, C) {
			var G = GJ.guid();
			E = w(E);
			var B = k.cache[G] = {
				id : G,
				dependencies : E,
				status : g.SAVED,
				factory : D,
				onError : C
			};
			var F = z[G] = GJ.Deferred();
			if (GJ.isFunction(C)) {
				F.fail(C)
			}
			f.push([ -(p - new Date), "use", G ]);
			i(G)
		};
		k.async = GJ.use;
		GJ.add = function(E, F, D, C) {
			var B = k.cache[E], G = z[E];
			if (B && B.status >= g.SAVED) {
				GJ.log(E + " 重复载入[" + B.status + "]");
				return
			}
			if (GJ.isFunction(F)) {
				C = D;
				D = F;
				F = []
			}
			F = w(F);
			if (B) {
				B.dependencies = F;
				B.status = g.SAVED;
				B.factory = D;
				B.onError = C;
				B.exports = {}
			} else {
				k.cache[E] = {
					id : E,
					uri : E,
					dependencies : F,
					status : g.SAVED,
					factory : D,
					onError : C,
					exports : {}
				};
				B = k.cache[E]
			}
			if (!G) {
				G = z[E] = GJ.Deferred()
			}
			f.push([ -(p - new Date), "add", E ]);
			if (GJ.isFunction(C)) {
				G.fail(C)
			}
			i(E)
		};
		function i(C) {
			var B = k.cache[C];
			var E = [];
			f.push([ -(p - new Date), "waiting", C ]);
			GJ.each(B.dependencies, function(F) {
				if (F.status < g.FETCHING) {
					E.push(F.uri)
				}
			});
			GJ.each(E, function(F) {
				y(F)
			});
			var D = GJ.map(B.dependencies, function(F) {
				return z[F.id]
			});
			GJ.when.apply({}, D).done(function() {
				A(C)
			})
		}
		function A(G) {
			f.push([ -(p - new Date), "ready", G ]);
			var F = k.cache[G], H = z[G];
			F.exports = {};
			F.status = g.READY;
			if (GJ.isFunction(F.factory)) {
				F.status = g.COMPILING;
				try {
					if (F.uri) {
						F.pause = function() {
							F.status = g.PAUSE
						};
						F.resume = function() {
							delete F.pause;
							delete F.resume;
							F.status = g.COMPILED;
							H.done()
						};
						var D = F.factory.call(window, k, F.exports, F);
						if (D) {
							F.exports = D
						}
					} else {
						var C = GJ.map(F.dependencies, function(I) {
							return I.exports
						});
						F.factory.apply(window, C)
					}
				} catch (E) {
					GJ.log("MOD: " + G);
					GJ.log("DEP: "
							+ GJ.jsonEncode(GJ.map(F.dependencies, function(I) {
								return I.id
							})));
					GJ.log("ERR: " + E.message);
					F.status = g.ERROR;
					H.fail();
					var B = F.factory.toString();
					B = B.length > 150 ? B.substr(0, 150) : B;
					GJ.errorStack.push({
						type : "GJ_MODULE_CALLBACK_ERROR",
						message : E.message,
						uri : G,
						dependencies : GJ.jsonEncode(GJ.map(F.dependencies,
								function(I) {
									return I.id
								})),
						stack : E.stack,
						fn : B
					});
					throw E
				}
			}
			if (F.status === g.PAUSE) {
				return
			} else {
				F.status = g.COMPILED;
				H.done()
			}
		}
		function o(D) {
			var G = navigator.userAgent;
			var I = Number(G.replace(/.*AppleWebKit\/(\d+)\..*/, "$1")) < 536;
			var F = G.indexOf("Firefox") > 0
					&& !("onload" in document.createElement("link"));
			var C = k.cache[D];
			var E = a.createElement("link");
			var B;
			E.setAttribute("type", "text/css");
			E.setAttribute("href", u(D));
			E.setAttribute("rel", "stylesheet");
			if (I || F) {
				setTimeout(function() {
					H(E, J)
				}, 1)
			} else {
				E.onload = J;
				E.onerror = function() {
					clearTimeout(B);
					v.removeChild(E);
					x(D, "Load Fail")
				}
			}
			C.status = g.FETCHING;
			v.appendChild(E);
			B = setTimeout(function() {
				v.removeChild(E);
				x(D, "Load timeout")
			}, 30000);
			function J() {
				clearTimeout(B);
				f.push([ -(p - new Date), "loaded", D ]);
				if (C.status === g.FETCHING) {
					C.status = g.FETCHED
				}
				A(D)
			}
			function H(M, N) {
				var K;
				if (I) {
					if (M.sheet) {
						K = true
					}
				} else {
					if (M.sheet) {
						try {
							if (M.sheet.cssRules) {
								K = true
							}
						} catch (L) {
							if (L.name === "NS_ERROR_DOM_SECURITY_ERR") {
								K = true
							}
						}
					}
				}
				setTimeout(function() {
					if (K) {
						N()
					} else {
						H(M, N)
					}
				}, 1)
			}
			return E
		}
		function m(D, C) {
			var B = k.cache[D];
			var F;
			E();
			function E() {
				var I = setTimeout(function() {
					v.removeChild(H);
					x(D, "Load timeout")
				}, 30000);
				var H = a.createElement("script");
				var G = false;
				H.setAttribute("type", "text/javascript");
				H.setAttribute("src", u(D));
				H.setAttribute("async", true);
				H.onload = H.onreadystatechange = function() {
					if (!G
							&& (!this.readyState || this.readyState == "loaded" || this.readyState == "complete")) {
						G = true;
						clearTimeout(I);
						f.push([ -(p - new Date), "loaded", D ]);
						if (B.status === g.FETCHING) {
							B.status = g.FETCHED
						}
						if (GJ.isFunction(C)) {
							C()
						}
						if (B.status < g.SAVED) {
							if (!/^http/.test(D)) {
								GJ.log("模块ID错误: " + D);
								GJ.tralog("GJ_ADD_INVALIDATE", D);
								if (!GJ.config.debug) {
									GJ.setCookie("use_https", 1, 86400);
									GJ.config.defaultServer = "https://sta.ganji.com"
								}
							} else {
								A(D)
							}
						}
					}
				};
				H.onerror = function(J) {
					clearTimeout(I);
					v.removeChild(H);
					x(D, "Load Fail")
				};
				B.status = g.FETCHING;
				v.appendChild(H)
			}
		}
		function s(C) {
			var D = d[C];
			var B;
			if (!D) {
				throw new Error(C + "is not a combined js file")
			}
			D = w(D);
			if (!r) {
				GJ.each(D, function(E) {
					if (E.status < g.FETCHING && E.uri.indexOf(".js") !== -1) {
						E.status = g.FETCHING
					}
				});
				if (C.indexOf(".css") === -1) {
					B = m
				} else {
					B = o
				}
				B(C, function() {
					GJ.add(C, d[C])
				})
			} else {
				GJ.add(C, d[C])
			}
		}
		function y(D) {
			f.push([ -(p - new Date), "fetching", D ]);
			if (d[D]) {
				return s(D)
			}
			var B = GJ.Module.fileLoaders;
			for ( var C in B) {
				if (B.hasOwnProperty(C)) {
					if (D.indexOf(C) !== -1) {
						return B[C](D)
					}
				}
			}
			return B[".js"].call({
				require : k,
				defers : z
			}, D)
		}
		var c = {}, j = 0;
		function x(B, C) {
			if (c[B]) {
				k.cache[B].status = g.FAILED;
				z[B].fail();
				GJ.errorStack.push({
					type : "GJ_MODULE_FAIL",
					message : C,
					uri : B
				});
				throw new Error(C + ": " + u(B))
			} else {
				c[B] = true;
				if (/^http/.test(B)) {
					throw new Error(C + ": " + B)
				}
				GJ.tralog("MODULE_LOAD_FAIL", GJ.config.defaultServer + " - "
						+ B);
				j = j + 1 >= GJ.config.servers.length ? 0 : j + 1;
				GJ.config.defaultServer = GJ.config.servers[j];
				GJ.setCookie("STA_DS", j);
				y(B)
			}
		}
		function w(B) {
			var C = [];
			if (B && typeof B === "string") {
				B = B.replace(/^ */, "");
				B = B.split(/[, \r\n\t\f]+/)
			}
			GJ.each(B, function(D) {
				GJ.each(k.resolve(D), function(E) {
					if (GJ.inArray(E, C) === -1) {
						C.push(E)
					}
				})
			});
			C = GJ.map(C, function(D) {
				if (!k.cache[D]) {
					k.cache[D] = {
						id : D,
						uri : D,
						dependencies : [],
						status : 0
					};
					z[D] = GJ.Deferred()
				}
				return k.cache[D]
			});
			return C
		}
	}();
	GJ.jsonp = function(c, e, k, i, m) {
		if (!c) {
			alert("[GJ.jsonp]url不能为空 ");
			return
		}
		if (GJ.isFunction(e)) {
			m = i;
			i = k;
			k = e;
			e = {}
		}
		if (!m) {
			m = GJ.guid()
		}
		c += c.indexOf("?") === -1 ? "?" : "&";
		c += "postData=" + encodeURIComponent(GJ.jsonEncode(e));
		c += "&callbackName=" + encodeURIComponent(m);
		var o = document, f, h = false, j = function() {
			if (!h && GJ.isFunction(i)) {
				h = true;
				i()
			}
		};
		var l = document.getElementsByTagName("head")[0];
		window[m] = function(n) {
			h = true;
			if (GJ.isFunction(k)) {
				k(n)
			}
		};
		f = o.createElement("script");
		f.setAttribute("type", "text/javascript");
		f.setAttribute("src", c);
		f.setAttribute("async", true);
		var d = GJ.later(function() {
			j();
			GJ.error("文件载入失败: '" + c + "'");
			l.removeChild(f)
		}, 30 * 1000, false);
		var g = false;
		f.onload = f.onreadystatechange = function() {
			if (!g
					&& (!this.readyState || this.readyState == "loaded" || this.readyState == "complete")) {
				g = true;
				d.cancel();
				j()
			}
		};
		f.onerror = function(n) {
			d.cancel();
			j();
			GJ.error(n + ": " + c);
			l.removeChild(f)
		};
		l.appendChild(f)
	};
	GJ.ua = function() {
		var h = function(e) {
			var m = 0;
			return parseFloat(e.replace(/\./g, function() {
				return (m++ == 1) ? "" : "."
			}))
		}, c = b && b.navigator, d = c && c.userAgent, j = b && b.location, f = j
				&& j.href, i, g = {
			ie : 0,
			opera : 0,
			gecko : 0,
			webkit : 0,
			chrome : 0,
			mobile : null,
			air : 0,
			ipad : 0,
			iphone : 0,
			ipod : 0,
			ios : null,
			android : 0,
			caja : c && c.cajaVersion,
			secure : false,
			os : null,
			isqplus : false,
			is360app : false
		};
		g.secure = f && (f.toLowerCase().indexOf("https") === 0);
		if (d) {
			if ((/windows|win32/i).test(d)) {
				g.os = "windows"
			} else {
				if ((/macintosh/i).test(d)) {
					g.os = "macintosh"
				} else {
					if ((/rhino/i).test(d)) {
						g.os = "rhino"
					}
				}
			}
			if ((/KHTML/).test(d)) {
				g.webkit = 1
			}
			i = d.match(/AppleWebKit\/([^\s]*)/);
			if (i && i[1]) {
				g.webkit = h(i[1]);
				if (/ Mobile\//.test(d)) {
					g.mobile = "Apple";
					i = d.match(/OS ([^\s]*)/);
					if (i && i[1]) {
						i = h(i[1].replace("_", "."))
					}
					g.ipad = (navigator.platform == "iPad") ? i : 0;
					g.ipod = (navigator.platform == "iPod") ? i : 0;
					g.iphone = (navigator.platform == "iPhone") ? i : 0;
					g.ios = g.ipad || g.iphone || g.ipod
				} else {
					i = d.match(/NokiaN[^\/]*|Android \d\.\d|webOS\/\d\.\d/);
					if (i) {
						g.mobile = i[0]
					}
					if (/ Android/.test(d)) {
						g.mobile = "Android";
						i = d.match(/Android ([^\s]*);/);
						if (i && i[1]) {
							g.android = h(i[1])
						}
					}
				}
				i = d.match(/Chrome\/([^\s]*)/);
				if (i && i[1]) {
					g.chrome = h(i[1])
				} else {
					i = d.match(/AdobeAIR\/([^\s]*)/);
					if (i) {
						g.air = i[0]
					}
				}
			}
			if (!g.webkit) {
				i = d.match(/Opera[\s\/]([^\s]*)/);
				if (i && i[1]) {
					g.opera = h(i[1]);
					i = d.match(/Opera Mini[^;]*/);
					if (i) {
						g.mobile = i[0]
					}
				} else {
					i = d.match(/MSIE\s([^;]*)/);
					if (i && i[1]) {
						g.ie = h(i[1])
					} else {
						i = d.match(/Gecko\/([^\s]*)/);
						if (i) {
							g.gecko = 1;
							i = d.match(/rv:([^\s\)]*)/);
							if (i && i[1]) {
								g.gecko = h(i[1])
							}
						}
					}
					var l = new RegExp("Trident/.*rv:([0-9]{1,}[.0-9]{0,})");
					if (l.exec(d) != null) {
						g.ie = parseFloat(RegExp.$1)
					}
				}
			}
		}
		try {
			if (b.external && b.external.qplus && GJ.isObject(b.external.qplus)) {
				g.isqplus = true
			}
			if (!g.isqplus && b.external && b.external.wappGetAppId
					&& b.external.wappGetAppId()) {
				g.is360app = true
			}
		} catch (k) {
		}
		return g
	}();
	GJ.getViewPort = function() {
		var f = document, d = f.body, h = f.documentElement, g = f.compatMode, e = self.innerWidth, c = self.innerHeight;
		if (g || GJ.ua.ie) {
			e = (g == "CSS1Compat") ? h.clientWidth : d.clientWidth;
			if (!GJ.ua.opera) {
				c = (g == "CSS1Compat") ? h.clientHeight : d.clientHeight
			}
		}
		return {
			left : Math.max(h.scrollLeft, d.scrollLeft),
			top : Math.max(h.scrollTop, d.scrollTop),
			width : e,
			height : c
		}
	};
	GJ.trim = function(c) {
		return c.replace(/^\s+/, "").replace(/\s+$/, "")
	};
	GJ.sprintf = function(g, f, e) {
		var c = arguments, g = c[0] || "", d, h;
		for (d = 1, h = c.length; d < h; d++) {
			g = g.replace(/%s/, c[d])
		}
		return g
	};
	GJ.parseUrl = function(d) {
		var g = document, h = g.location, c = g.createElement("a");
		d = d || h.href;
		if (d.indexOf("://") === -1 && GJ.ua.ie) {
			var e = h.protocol + "//" + h.host;
			if (d.indexOf("/") === 0) {
				e += d
			} else {
				e += h.pathname.replace(/\/[\w\.]+$/, "/") + d
			}
			d = e
		}
		c.href = d;
		var f = {
			source : d,
			protocol : c.protocol.replace(":", ""),
			host : c.hostname,
			port : c.port,
			query : c.search,
			params : (function() {
				var l = {}, o = d.replace(/^[^\?]+/, "").replace(/#.*$/, ""), k = o
						.replace(/^\?/, "").split("&"), j = k.length, m = 0, n;
				for (; m < j; m++) {
					if (!k[m]) {
						continue
					}
					n = k[m].split("=");
					l[n[0]] = n[1] || ""
				}
				return l
			})(),
			file : (c.pathname.match(/\/([^\/?#]+)$/i) || [ , "" ])[1],
			hash : c.hash.replace("#", ""),
			path : c.pathname.replace(/^([^\/])/, "/$1"),
			relative : (c.href.match(/tps?:\/\/[^\/]+(.+)/) || [ , "" ])[1],
			segments : c.pathname.replace(/^\//, "").split("/")
		};
		return f
	};
	GJ.checkFlashPlayer = function(f) {
		var k = navigator, j = null, g = f.split("."), h = [ 0, 0, 0 ];
		if (typeof k.plugins != "undefined"
				&& typeof k.plugins["Shockwave Flash"] == "object") {
			j = k.plugins["Shockwave Flash"].description;
			if (j
					&& !(typeof k.mimeTypes != "undefined"
							&& k.mimeTypes["application/x-shockwave-flash"] && !k.mimeTypes["application/x-shockwave-flash"].enabledPlugin)) {
				j = j.replace(/^.*\s+(\S+\s+\S+$)/, "$1");
				h[0] = parseInt(j.replace(/^(.*)\..*$/, "$1"), 10);
				h[1] = parseInt(j.replace(/^.*\.(.*)\s.*$/, "$1"), 10);
				h[2] = /[a-zA-Z]/.test(j) ? parseInt(j.replace(
						/^.*[a-zA-Z]+(.*)$/, "$1"), 10) : 0
			}
		} else {
			if (typeof window.ActiveXObject != "undefined") {
				try {
					var c = new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
					if (c) {
						j = c.GetVariable("$version");
						if (j) {
							j = j.split(" ")[1].split(",");
							h = [ parseInt(j[0], 10), parseInt(j[1], 10),
									parseInt(j[2], 10) ]
						}
					}
				} catch (i) {
				}
			}
		}
		g[0] = parseInt(g[0], 10);
		g[1] = parseInt(g[1], 10) || 0;
		g[2] = parseInt(g[2], 10) || 0;
		return (h[0] > g[0] || (h[0] == g[0] && h[1] > g[1]) || (h[0] == g[0]
				&& h[1] == g[1] && h[2] >= g[2])) ? true : false
	};
	(function() {
		var c;
		GJ.createCSS = function(d, i) {
			if (GJ.ua.ie && GJ.ua.mac) {
				return
			}
			try {
				var k = document, g = k.getElementsByTagName("head")[0];
				if (!g) {
					return
				}
				if (!c) {
					var f = k.createElement("style");
					f.setAttribute("type", "text/css");
					c = g.insertBefore(f, g.firstChild);
					if (GJ.ua.ie && GJ.ua.os == "win"
							&& !GJ.isUndefined(k.styleSheets)
							&& k.styleSheets.length > 0) {
						c = k.styleSheets[k.styleSheets.length - 1]
					}
				}
				if (GJ.ua.ie && GJ.ua.os == "win") {
					if (c && GJ.isFunction(c.addRule)) {
						c.addRule(d, i)
					}
				} else {
					if (c && GJ.isFunction(k.createTextNode)) {
						c.appendChild(k.createTextNode(d + " {" + i + "}"))
					}
				}
			} catch (j) {
			}
		}
	})();
	GJ.createLoading = function(e, c) {
		var f = 1, d = {
			remove : function() {
				if (f) {
					f.hide().remove()
				}
				f = null
			}
		};
		GJ
				.use(
						"jquery",
						function() {
							if (f === 1) {
								f = $('<div style="width:16px;height:16px;z-index:9000000;position:absolute;background-image:url('
										+ GJ
												.getFormatUrl("js/util/ganji/loading.gif")
										+ ');"></div>');
								$body = $("body");
								if ($body.size() == 0) {
									return
								}
								$body.append(f);
								if (!e) {
									var k = GJ.getViewPort(), j = k.left
											+ Math
													.round((k.width - f.width()) / 2), i = k.top
											+ Math
													.round((k.height - f
															.height()) / 2);
									f.css({
										top : Math.max(0, i),
										left : Math.max(0, j)
									})
								} else {
									var g = $(e), h = g.offset(), j, i;
									if (!c) {
										c = "center"
									}
									if (c == "center") {
										j = h.left
												+ Math.round((g.width() - f
														.width()) / 2)
									} else {
										if (c == "right") {
											j = h.left + g.width() + 5
										} else {
											if (c == "left") {
												j = h.left - f.width() - 5
											}
										}
									}
									i = h.top
											+ Math.round((g.height() - f
													.height()) / 2);
									f.css({
										top : i,
										left : j
									})
								}
								f.show()
							}
						});
		return d
	};
	GJ.oneEvent = function(g, e, c, f, d) {
		GJ.use("jquery", function() {
			var h = GJ.isString(g) ? $("#" + g) : $(g);
			if (!h || h.size() == 0) {
				return
			}
			h.one(e, function(j) {
				var i = this, k = GJ.createLoading(i);
				GJ.use(c, function() {
					k.remove();
					f.apply(i, [ j ])
				});
				return !!d
			})
		})
	};
	(function() {
		var g = window, f = document;
		try {
			f.execCommand("BackgroundImageCache", false, true)
		} catch (d) {
		}
		GJ.createCSS("object", "outline:none;");
		var c = GJ.config.documentDomain;
		if (c) {
			f.domain = c
		}
		var h = function() {
			GJ.use("jquery", function() {
				$("a").attr("target", "_self")
			})
		};
		GJ.addEvent(g, "load", function() {
			var e = window;
			if (GJ.ua.isqplus) {
				GJ.use("app_qplus", function() {
					GJ.qplus.init()
				})
			} else {
				if (GJ.ua.is360app) {
					h()
				}
			}
		})
	})();
	GJ.add("js/util/ganji/ganji.js")
})();
(function() {
	if (GJ.jsonEncode) {
		return
	}
	(function() {
		var _UNICODE_EXCEPTIONS = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, _ESCAPES = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, _VALUES = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, _BRACKETS = /(?:^|:|,)(?:\s*\[)+/g, _UNSAFE = /[^\],:{}\s]/, _escapeException = function(
				c) {
			return "\\u"
					+ ("0000" + (+(c.charCodeAt(0))).toString(16)).slice(-4)
		}, _parse = function(s, reviver) {
			s = s.replace(_UNICODE_EXCEPTIONS, _escapeException);
			if (!_UNSAFE.test(s.replace(_ESCAPES, "@").replace(_VALUES, "]")
					.replace(_BRACKETS, ""))) {
				return eval("(" + s + ")")
			}
			throw new SyntaxError("JSON.parse")
		};
		GJ.jsonDecode = function(s) {
			if (!GJ.isString(s)) {
				s += ""
			}
			return _parse(s)
		}
	})();
	(function() {
		var isFunction = GJ.isFunction, isObject = GJ.isObject, isArray = GJ.isArray, _toStr = Object.prototype.toString, UNDEFINED = "undefined", OBJECT = "object", NULL = "null", STRING = "string", NUMBER = "number", BOOLEAN = "boolean", DATE = "date", _allowable = {
			"undefined" : UNDEFINED,
			string : STRING,
			"[object String]" : STRING,
			number : NUMBER,
			"[object Number]" : NUMBER,
			"boolean" : BOOLEAN,
			"[object Boolean]" : BOOLEAN,
			"[object Date]" : DATE,
			"[object RegExp]" : OBJECT
		}, _SPECIAL_CHARS = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, _CHARS = {
			"\b" : "\\b",
			"\t" : "\\t",
			"\n" : "\\n",
			"\f" : "\\f",
			"\r" : "\\r",
			'"' : '\\"',
			"\\" : "\\\\"
		}, dateToString = function(d) {
			function _zeroPad(v) {
				return v < 10 ? "0" + v : v
			}
			return d.getUTCFullYear() + "-" + _zeroPad(d.getUTCMonth() + 1)
					+ "-" + _zeroPad(d.getUTCDate()) + "T"
					+ _zeroPad(d.getUTCHours()) + ":"
					+ _zeroPad(d.getUTCMinutes()) + ":"
					+ _zeroPad(d.getUTCSeconds()) + "Z"
		};
		function _type(o) {
			var t = typeof o;
			return _allowable[t] || _allowable[_toStr.call(o)]
					|| (t === OBJECT ? (o ? OBJECT : NULL) : UNDEFINED)
		}
		function _char(c) {
			if (!_CHARS[c]) {
				_CHARS[c] = "\\u"
						+ ("0000" + (+(c.charCodeAt(0))).toString(16))
								.slice(-4)
			}
			return _CHARS[c]
		}
		function _string(s) {
			return '"' + s.replace(_SPECIAL_CHARS, _char) + '"'
		}
		function _indent(s, space) {
			return s.replace(/^/gm, space)
		}
		function _stringify(o, space) {
			if (o === undefined) {
				return undefined
			}
			var w = null;
			var format = _toStr.call(space).match(/String|Number/) || [], stack = [];
			space = format[0] === "Number" ? new Array(Math.min(Math.max(0,
					space), 10) + 1).join(" ") : (space || "").slice(0, 10);
			function _serialize(h, key) {
				var value = h[key], t = _type(value), a = [], colon = space ? ": "
						: ":", arr, i, keys, k, v;
				if (isObject(value) && isFunction(value.toJSON)) {
					value = value.toJSON(key)
				} else {
					if (t === DATE) {
						value = dateToString(value)
					}
				}
				if (value !== h[key]) {
					t = _type(value)
				}
				switch (t) {
				case DATE:
				case OBJECT:
					break;
				case STRING:
					return _string(value);
				case NUMBER:
					return isFinite(value) ? value + "" : NULL;
				case BOOLEAN:
					return value + "";
				case NULL:
					return NULL;
				default:
					return undefined
				}
				for (i = stack.length - 1; i >= 0; --i) {
					if (stack[i] === value) {
						throw new Error("JSON.stringify. Cyclical reference")
					}
				}
				arr = isArray(value);
				stack.push(value);
				if (arr) {
					for (i = value.length - 1; i >= 0; --i) {
						a[i] = _serialize(value, i) || NULL
					}
				} else {
					keys = w || value;
					i = 0;
					for (k in keys) {
						if (keys.hasOwnProperty(k)) {
							v = _serialize(value, k);
							if (v) {
								a[i++] = _string(k) + colon + v
							}
						}
					}
				}
				stack.pop();
				if (space && a.length) {
					return arr ? "[\n" + _indent(a.join(",\n"), space) + "\n]"
							: "{\n" + _indent(a.join(",\n"), space) + "\n}"
				} else {
					return arr ? "[" + a.join(",") + "]" : "{" + a.join(",")
							+ "}"
				}
			}
			return _serialize({
				"" : o
			}, "")
		}
		GJ.jsonEncode = function(o, ind) {
			return _stringify(o, ind)
		}
	})();
	GJ.add("js/util/json/json.js")
})();
window.onerror = function(c, b, a) {
	GJ.errorManager.send(c, b + "[" + a + "]", "WINDOW_ON_ERROR")
};
if (window.location.href.indexOf("use_https") !== -1) {
	GJ.setCookie("use_https", 1, 86400)
}
if (GJ.getCookie("use_https")) {
	GJ.defaultServer = "https://sta.ganji.com"
};