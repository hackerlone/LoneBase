$(document).ready(function(){
          var carInfo=null;
         var carid=null;
     $(".active").click(function(){
         carInfo=$(".carbrand").text();
          $("#rOneWrap").empty();
         secmakecar();
     });
     	function secmakecar(){
		$.ajax({
			url:'car_getallcar',
			type:'post',
			data:{"carInfo":carInfo},
			dataType:'json',
			success:function (data){
				$(data).each(function(i,obj){
					$("#rOneWrap").append("<p id='carid' hidden='hidden'>"+obj.cid+"</p><div class='ontag' ></div><div id='car' class='list-infoBox'>"+
						"<a title='"+obj.brand+"  "+obj.chexing+"' target='_blank' class='imgtype'	gjalog='100000000057000100000010@city_id=45@around_city_id=45'>"+
						"<span class='hover-bg'></span> <img width='290' height='192' class='js-lazy-load'	data-original='http://scs.ganjistatic1.com/gjfs15/M08/0E/08/CgEHQFZTD8nKrPhGABZ4XCW3SN0169_290-192c_8-1.jpg'"+
						"src='upload/"+obj.image+"'	alt='"+obj.brand+"  "+obj.chexing+"'	style='visibility: visible; display: inline;'> </a>"+
						"<p class='infoBox'><a 	title='"+obj.brand+"  "+obj.chexing+"' target='_blank' class='info-title'"+
						"gjalog='100000000057000100000010@city_id=45@around_city_id=45'>"+obj.brand+"  "+obj.chexing+"</a>"+
						"</p><p class='fc-gray'><span>"+(obj.registration).substring(0,10)+"上牌</span> <em class='shuxian'>|</em>行驶 "+Math.round((obj.kilometre)*100)/100+"万公里</p>"+
						"<p class='priType-s'><span> <i class='fc-org priType'>"+obj.price+"</i>万 </span> <s>"+Math.round((obj.price*1.1)*100)/100+"万</s>"+
						"</p></div>");
				});
				$(".list-infoBox").click(function(){
					alert("sss")
				carid=$(this).parents("div").children("p:first").text();
				alert(carid);
			    location.href = "car_getCarInfoById.action?id="+carid+"&option=update"
				});
			}});
		}
});
