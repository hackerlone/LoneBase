package gxa.dao;

import gxa.entity.Users;
import java.util.List;

import org.hibernate.Session;

public class UserDao extends BaseDaoImp implements UserDaoI{
	public List<Users> getAllUser() throws Exception{
		return this.getSession().createQuery("From Users").list();
	
	}
	public Users getUsersById(int id) throws Exception {
		Session session = this.getSession();

		Users users = (Users) session.load(Users.class, id);
		return users;
	}
	public void update(Users users) throws Exception {
        this.getHibernateTemplate(). update(users);
		return;
	}
	public void add(Users users) throws Exception {
		
        this.getHibernateTemplate().save(users);
		return;
	}
}
