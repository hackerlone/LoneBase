package gxa.dao;

import gxa.entity.Admin;

import gxa.page.PageInfo;

import java.util.List;

import org.hibernate.Session;

public class AdminDao extends BaseDaoImp implements AdminDaoI{
//��ѯ���й���Ա
	public List<Admin> getAllAdmin() throws Exception{
		return this.getSession().createQuery("From Admin").list();	
	}
//�޸�ĳһ������Ա
	public Admin getAdminById(int id)throws Exception{
		Session session = this.getSession();
		
		Admin admin = (Admin) session.load(Admin.class,id);
		return admin;
	}
	public void update(Admin admin) throws Exception {
        this.getHibernateTemplate().update(admin);
		return;
	}
//���ӵ�������Ա
	public void addAdmin(Admin admin) throws Exception{             //�������Ա����  
        
		this.getHibernateTemplate().save(admin); 
        
        return;
    }
}
