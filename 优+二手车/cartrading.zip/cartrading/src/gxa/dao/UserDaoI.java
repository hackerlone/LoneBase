package gxa.dao;

import gxa.entity.Users;

import java.util.List;

public interface UserDaoI extends BaseDaoI {
	public List<Users> getAllUser() throws Exception;
	  public Users getUsersById(int id) throws Exception;
	  public void update(Users users) throws Exception;
	  public void add(Users users) throws Exception;
}
