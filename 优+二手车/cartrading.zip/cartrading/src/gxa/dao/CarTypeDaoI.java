package gxa.dao;

import gxa.entity.Admin;
import gxa.entity.CarType;
import gxa.entity.CarType;

import java.util.List;

public interface CarTypeDaoI extends BaseDaoI {
	public List<CarType> getAllCarType() throws Exception;
	
	public CarType getCarTypeById(int id) throws Exception;
	public void update(CarType cartype) throws Exception;
	 public void addCarType(CarType cartype) throws Exception;      //���泵������
}
