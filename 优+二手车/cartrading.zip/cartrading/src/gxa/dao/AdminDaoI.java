package gxa.dao;

import gxa.entity.Admin;


import java.util.List;

public interface AdminDaoI extends BaseDaoI {
	public List<Admin> getAllAdmin() throws Exception;
	
	public Admin getAdminById(int id) throws Exception;
	public void update(Admin admin) throws Exception;
	
	
	 public void addAdmin(Admin admin) throws Exception;      //�����û�  
	
}
