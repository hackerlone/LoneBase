package gxa.dao;

import gxa.entity.Car;
import gxa.entity.Users;

import java.util.List;

import org.hibernate.Session;

public class CarDao extends BaseDaoImp implements CarDaoI{
	public List<Car> getAllCar() throws Exception{
		return this.getSession().createQuery("From Car").list();
	
	}
	public List<Car> getAllCar(int id) throws Exception{
		return this.getSession().createQuery("From Car where u_id="+id).list();
	
	}
	public Car getCarById(int id) throws Exception {
		Session session = this.getSession();

		Car car = (Car) session.load(Car.class, id);
		return car;
	}
	public void update(Car car) throws Exception {
        this.getHibernateTemplate().update(car);	
		return;
	}
public void add(Car car) throws Exception {
		
        this.getHibernateTemplate().save(car);
		return;
	}
public Car deleteCarById(int id) throws Exception {
	Session session = this.getSession();

	Car car = (Car) session.load(Car.class, id);
	return car;
}
public void delete(Car car) throws Exception {
    this.getHibernateTemplate().delete(car);	
	return;
}
}
