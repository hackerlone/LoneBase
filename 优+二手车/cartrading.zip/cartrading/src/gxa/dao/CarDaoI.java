package gxa.dao;

import gxa.entity.Car;
import gxa.entity.Users;

import java.util.List;

public interface CarDaoI extends BaseDaoI {
	public List<Car> getAllCar() throws Exception;
	public List<Car> getAllCar(int id) throws Exception;
	public Car getCarById(int id) throws Exception;
	public void update(Car car) throws Exception;
	public void add(Car car) throws Exception;
	public Car deleteCarById(int id) throws Exception;
	public void delete(Car car) throws Exception;
}
