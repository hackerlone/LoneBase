package gxa.controller;

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;

import gxa.entity.Car;
import gxa.entity.HibernateSessionFactory;
import gxa.entity.Users;
import gxa.page.PageInfo;
import gxa.service.UserServiceI;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {
	private UserServiceI userServiceI;
	private Users users;
	PageInfo pageInfo;

	public UserServiceI getUserServiceI() {
		return userServiceI;
	}

	public void setUserServiceI(UserServiceI userServiceI) {
		this.userServiceI = userServiceI;
	}

	public Users getUser() {
		return users;
	}

	public void setUser(Users users) {
		this.users = users;
	}

	public PageInfo getPageInfo() {
		return pageInfo;
	}

	public void setPageInfo(PageInfo pageInfo) {
		this.pageInfo = pageInfo;
	}

	public String getAllUser() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		String offset = request.getParameter("offset");
		pageInfo.setFirstResult(offset);
		if (offset == null) {
			pageInfo.setFirstResult("0");
		}
		List<Users> users = userServiceI.getAllUser(pageInfo);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("users", users);
		return "getalluser";
	}
	public String getAllUser1() throws Exception {
		return "off";
	}
	public String getUsersById() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		int id = Integer.parseInt(request.getParameter("id"));
		String option = request.getParameter("option");
		users = userServiceI.getUsersById(id);
		if (option.equals("update")) {
			List<Car> cars=users.getCars();
			String url = "getUsersById.action?id" + id + "&option=update";
			ActionContext.getContext().getValueStack().set("url", url);
			 ServletActionContext.getRequest().setAttribute("cars", cars);
			 System.out.println(cars);
			return "update";
		}
		return "none";
	}

	public String update() throws Exception {
		userServiceI.update(users);
		getAllUser();
		return "updateu";
	}

	public String getUserCar() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		int id = Integer.parseInt(request.getParameter("id"));
		String option = request.getParameter("option");
		users = userServiceI.getUsersById(id);
		if (option.equals("update")) {
			List<Car> cars=users.getCars();
			String url = "getUserCar.action?id" + id + "&option=update";
			ActionContext.getContext().getValueStack().set("url", url);
			 ServletActionContext.getRequest().setAttribute("cars", cars);
			 System.out.println(cars);
			return "update1";
		}
		return "none";
	}
String longinno=null;
	public String add() throws Exception {
		userServiceI.add(users);
		//ǰ��̨ע����ת�ж�
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session1=request.getSession();
		longinno=(String) session1.getAttribute("longinno");
		System.out.println(longinno);
		 if(longinno.equals("off")){
				getAllUser1();
				longinno="off";
			}else {
				getAllUser();
				longinno="add";
			}
		return longinno;
	}
public String login() throws Exception {
		
		Session session = (Session) HibernateSessionFactory.getSession();
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("textml;charset=utf-8");
		String u_name = request.getParameter("u_name");
		String u_pwd = request.getParameter("u_pwd");
	System.out.println(u_name);
	System.out.println(u_pwd);
		Query query = session.createSQLQuery("SELECT u_id,u_pwd FROM users where u_name="+"'"+u_name+"' or  u_phone="+"'"+u_name+"'");
	    Iterator its =  query.list().iterator();
	    while(its.hasNext()){
	    	Object [] O=((Object [])its.next());
	    	 if(u_pwd.equals(O[1])){
	 	    	System.out.println(u_name);
	 	    	System.out.println("�˺ţ�"+O[0]);
	 	    	  HttpSession session1=request.getSession();
	 	    	  session1.setAttribute("name", u_name);
	 	    	  session1.setAttribute("id", O[0]);  
	 	    }  	
	    }
		return "";
	}
}
