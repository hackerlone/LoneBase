package gxa.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import gxa.entity.Admin;

import gxa.page.PageInfo;
import gxa.service.AdminServiceI;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class AdminAction extends ActionSupport {
	private AdminServiceI adminServiceI;
	private Admin admin;
	PageInfo pageInfo;
	public AdminServiceI getAdminServiceI() {
		return adminServiceI;
	}
	public void setAdminServiceI(AdminServiceI adminServiceI) {
		this.adminServiceI = adminServiceI;
	}
	public Admin getAdmin() {
		return admin;
	}
	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	public PageInfo getPageInfo() {
		return pageInfo;
	}
	public void setPageInfo(PageInfo pageInfo) {
		this.pageInfo = pageInfo;
	}
	//��ѯ���й���Ա
	public  String getAllAdmin() throws Exception{
		HttpServletRequest request = ServletActionContext.getRequest();
		String offset = request.getParameter("offset");
		pageInfo.setFirstResult(offset);
		if(offset==null){
		pageInfo.setFirstResult("0");
		}
		List<Admin> admins = adminServiceI.getAllAdmin(pageInfo);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("admins", admins);
		return "getallsuc";
	}
	//�޸�ĳһ������Ա��Ϣ
	public String getAdminById() throws Exception{
		 HttpServletRequest request =  ServletActionContext.getRequest();
		   int id = Integer.parseInt(request.getParameter("id"));
		   String option = request.getParameter("option");
		   admin = adminServiceI.getAdminById(id);
		   if(option.equals("update")){
			   
			   String url = "getAdminById.action?id"+id+"&option=update";
			   ActionContext.getContext().getValueStack().set("url", url);
			   return "update";
		   }
		return "none";
	}
	//���²���
	public String update() throws Exception{
		  adminServiceI.update(admin);	
		  getAllAdmin();
	    return "updatesuc";

	  }
//���ӹ���Ա��Ϣ
	public String addAdmin() throws Exception{ 
		 	   adminServiceI.addAdmin(admin);	
		 	  getAllAdmin();		
		return "addsuc";
		
	}

}
