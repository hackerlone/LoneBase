package gxa.controller;

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import gxa.entity.CarType;
import gxa.entity.HibernateSessionFactory;
import gxa.page.PageInfo;
import gxa.service.CarTypeServiceI;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class CarTypeAction extends ActionSupport {
	private CarTypeServiceI carTypeServiceI;
	private CarType carType;
	PageInfo pageInfo;

	public CarTypeServiceI getCarTypeServiceI() {
		return carTypeServiceI;
	}

	public void setCarTypeServiceI(CarTypeServiceI carTypeServiceI) {
		this.carTypeServiceI = carTypeServiceI;
	}

	public CarType getCarType() {
		return carType;
	}

	public void setCarType(CarType carType) {
		this.carType = carType;
	}

	public PageInfo getPageInfo() {
		return pageInfo;
	}

	public void setPageInfo(PageInfo pageInfo) {
		this.pageInfo = pageInfo;
	}

	// ��ѯ���г�������
	public String getAllCarType() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		String offset = request.getParameter("offset");
		pageInfo.setFirstResult(offset);
		if (offset == null) {
			pageInfo.setFirstResult("0");
		}
		List<CarType> carTypes = carTypeServiceI.getAllCarType(pageInfo);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("carTypes", carTypes);
		return "getallsuc";
	}

	// �޸�ĳһ������������Ϣ
	public String getCarTypeById() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		int id = Integer.parseInt(request.getParameter("id"));
		String option = request.getParameter("option");
		carType = carTypeServiceI.getCarTypeById(id);
		if (option.equals("update")) {

			String url = "getCarTypeById.action?id" + id + "&option=update";
			ActionContext.getContext().getValueStack().set("url", url);
			return "update";
		}
		return "none";
	}

	// ���²���
	public String update() throws Exception {
		carTypeServiceI.update(carType);
		getAllCarType();
		return "updatesuc";
	}
	//���ӳ�����Ϣ
	public String addCarType() throws Exception{
		carTypeServiceI.addCarType(carType);
		
		getAllCarType();
		return "addsuc";
	
	}
	public String getallmake() throws Exception {
	Session session = (Session) HibernateSessionFactory.getSession();
	HttpServletResponse response = ServletActionContext.getResponse();
	HttpServletRequest request = ServletActionContext.getRequest();
//	System.out.println(request.getParameter("pinpai"));
	
	response.setContentType("text/html;charset=utf-8");
//	 Transaction tx = session.beginTransaction(); 
	Query query = session.createSQLQuery("SELECT distinct make_name FROM cartype ");
	Iterator its =  query.list().iterator();
	StringBuilder make = new StringBuilder();
	make.append("[");
	while(its.hasNext()){
		make.append("{\"make\":");
		make.append("\"");
		make.append(its.next());
		make.append("\"}");
		if(its.hasNext()){
		make.append(",");
		}
	}
	make.append("]");
	System.out.println(make);
//   tx.commit(); 
   session.close(); 
   PrintWriter out = response.getWriter();
	out.println(make);
	out.flush();
	return "";
 }
	public String getallmodel() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		 String make1=request.getParameter("makes");
		 System.out.println(make1);
		Session session = (Session) HibernateSessionFactory.getSession();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		Query query = session.createSQLQuery("SELECT distinct model_name FROM cartype where make_name="+"'"+make1+"'");
		Iterator its =  query.list().iterator();
		StringBuilder model = new StringBuilder();
		model.append("[");
		while(its.hasNext()){
			model.append("{\"model\":");
			model.append("\"");
			model.append(its.next());
			model.append("\"}");
			if(its.hasNext()){
			model.append(",");
			}
		}
		model.append("]");
		System.out.println(model);
	   session.close(); 
	   PrintWriter out = response.getWriter();
		out.println(model);
		out.flush();
		return "";
	 }
	public String getalltype() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		 String models=request.getParameter("models");
		 System.out.println(models);
		Session session = (Session) HibernateSessionFactory.getSession();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		Query query = session.createSQLQuery("SELECT distinct type_name FROM cartype where model_name="+"'"+models+"'");
		Iterator its =  query.list().iterator();
		StringBuilder type = new StringBuilder();
		type.append("[");
		while(its.hasNext()){
			type.append("{\"type\":");
			type.append("\"");
			type.append(its.next());
			type.append("\"}");
			if(its.hasNext()){
			type.append(",");
			}
		}
		type.append("]");
		System.out.println(type);
	   session.close(); 
	   PrintWriter out = response.getWriter();
		out.println(type);
		out.flush();
		return "";
	 }
	public String getallreference() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		String type=request.getParameter("type");
		//System.out.println(type+"ssssss");
		Session session = (Session) HibernateSessionFactory.getSession();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("textml;charset=utf-8");
		Query query = session.createSQLQuery("SELECT distinct c_id,price FROM car where carseries="+"'"+type+"'");
		Iterator its =  query.list().iterator();
		StringBuilder reference = new StringBuilder();
		reference.append("[");
		while(its.hasNext()){
			Object [] O=((Object [])its.next());
				reference.append("{\"id\":");
				reference.append("\"");
				reference.append(O[0]);
				reference.append("\",\"reference\":");
				reference.append("\"");
				reference.append(O[1]);
				reference.append("\"}");
				if(its.hasNext()){
					reference.append(",");
				}
		}
		reference.append("]");
		System.out.println(reference+"wwwwww");
	   session.close(); 
	   PrintWriter out = response.getWriter();
		out.println(reference);
		out.flush();
		return "";
	 }
	public String getalltype1() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		 String models=request.getParameter("models");
		 String type1=request.getParameter("type1");
		// System.out.println(models);
		Session session = (Session) HibernateSessionFactory.getSession();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("textml;charset=utf-8");
		Query query = session.createSQLQuery("SELECT distinct ct_id FROM cartype where type_name="+"'"+type1+"' and model_name="+"'"+models+"'");
		Iterator its =  query.list().iterator();
		StringBuilder type = new StringBuilder();
		type.append("[");
		while(its.hasNext()){
			type.append("{\"id\":");
			type.append("\"");
			type.append(its.next());
			type.append("\"}");
			if(its.hasNext()){
			type.append(",");
			}
		}
		type.append("]");
		System.out.println(type+"gggggggg");
	   session.close(); 
	   PrintWriter out = response.getWriter();
		out.println(type);
		out.flush();
		return "";
	 }

}
