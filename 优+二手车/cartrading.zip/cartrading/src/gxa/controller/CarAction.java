package gxa.controller;

import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Query;
import org.hibernate.Session;

import gxa.entity.Car;
import gxa.entity.CarType;
import gxa.entity.HibernateSessionFactory;
import gxa.page.PageInfo;
import gxa.service.CarServiceI;
import gxa.service.CarTypeServiceI;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class CarAction extends ActionSupport {
	private CarServiceI carServiceI;
	private CarTypeServiceI carTypeServiceI;
	private Car car;
	private CarType carType;
	PageInfo pageInfo;

	public CarTypeServiceI getCarTypeServiceI() {
		return carTypeServiceI;
	}

	public void setCarTypeServiceI(CarTypeServiceI carTypeServiceI) {
		this.carTypeServiceI = carTypeServiceI;
	}

	public CarServiceI getCarServiceI() {
		return carServiceI;
	}

	public void setCarServiceI(CarServiceI carServiceI) {
		this.carServiceI = carServiceI;
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	public PageInfo getPageInfo() {
		return pageInfo;
	}

	public void setPageInfo(PageInfo pageInfo) {
		this.pageInfo = pageInfo;
	}

	// ��ѯ���г�����Ϣ
	public String getAllCar() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		String offset = request.getParameter("offset");
		pageInfo.setFirstResult(offset);
		if (offset == null) {
			pageInfo.setFirstResult("0");
		}
		List<Car> cars = carServiceI.getAllCar(pageInfo);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("cars", cars);
		return "getallcar";
	}

	
	// ��ѯ���޸�ĳһ��������Ϣ
	public String getCarById() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		//System.out.println(request.getParameter("cartypes"));
		int id = Integer.parseInt(request.getParameter("id"));
		String option = request.getParameter("option");
		car = carServiceI.getCarById(id);
//		System.out.println(carTypes);
		if (option.equals("update")) {
			String offset = request.getParameter("offset");
		    pageInfo.setFirstResult(offset);
			String url = "getCarById.action?id" + id + "&option=update";
			ActionContext.getContext().getValueStack().set("url", url);
			System.out.println(car.getCartypes().getMakeName());
			return "update";
		}
		return "none";

	}
	public String getCarInfoById() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		int id = Integer.parseInt(request.getParameter("id"));
		String option = request.getParameter("option");
		car = carServiceI.getCarById(id);
		carType=car.getCartypes();
		System.out.println(car.getCartypes()+"ssss");
		request.setAttribute("cars", car);
		request.setAttribute("carType", carType);
		if (option.equals("update")) {
			String offset = request.getParameter("offset");
		    pageInfo.setFirstResult(offset);
			String url = "getCarInfoById.action?id" + id + "&option=update";
			ActionContext.getContext().getValueStack().set("url", url);
			System.out.println(car.getBrand());
			System.out.println(carType.getEngineCapacity());
			return "carinfo";
		}
		
		return "none";

	}

	public String update() throws Exception {
		carServiceI.update(car);
		getAllCar();
		return "updatecar";

	}

	public String add() throws Exception {
		carServiceI.add(car);
		 ctid=getaddctid();
		Session session = (Session) HibernateSessionFactory.getSession();
		Query query1 = session.createSQLQuery("update car set ct_id="+ctid+" where c_id="+car.getCId()+"");
		query1.executeUpdate();
		getAllCar();
		return "getallcar1";
	}
	public String add1() throws Exception {
		carServiceI.add(car);
		 ctid=getaddctid();
		Session session = (Session) HibernateSessionFactory.getSession();
		Query query1 = session.createSQLQuery("update car set ct_id="+ctid+" where c_id="+car.getCId()+"");
		query1.executeUpdate();
		getAllCar();
		return "getallcar2";
	}
	  int ctid=0;
	public int getaddctid() throws Exception {
		
		Session session = (Session) HibernateSessionFactory.getSession();
		HttpServletResponse response = ServletActionContext.getResponse();
		HttpServletRequest request = ServletActionContext.getRequest();
		 String models=request.getParameter("models");
		 String type1=request.getParameter("type1");
		response.setContentType("textml;charset=utf-8");
		Query query = session.createSQLQuery("SELECT distinct ct_id FROM cartype where type_name="+"'"+type1+"' and model_name="+"'"+models+"'");
	    Iterator its =  query.list().iterator();
	  
	    while(its.hasNext()){
	   	ctid=(Integer) its.next();
	    }	    	
		return ctid;
		}

	
	
	public String deleteCarById() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		int id = Integer.parseInt(request.getParameter("id"));
		String option = request.getParameter("option");
		car = carServiceI.getCarById(id);
		carServiceI.delete(car);
		getAllCar();
		return "getallcar";

	}
	public String getallcar() throws Exception {
		System.out.println("rrrrrr");
		StringBuffer hql = new StringBuffer();
		hql.append("select  brand,chexing,price,image,kilometre,registration,c_id FROM car c Where 1=1 ");
		Session session = (Session) HibernateSessionFactory.getSession();
		HttpServletResponse response = ServletActionContext.getResponse();
		HttpServletRequest request = ServletActionContext.getRequest();
		String makes=request.getParameter("makes");
		 String models=request.getParameter("models");
		 String price=request.getParameter("price");
		 String carage=request.getParameter("carage");
		 String use=request.getParameter("use");
		 String kilometre=request.getParameter("kilometre");
		 String transmission=request.getParameter("transmission");
		 String engine=request.getParameter("engine");
		 String country=request.getParameter("country");
		 String city=request.getParameter("city");
		 String paixu=request.getParameter("paixu");
		 String carInfo=request.getParameter("carInfo");
		 response.setContentType("text/html;charset=utf-8");
		 //���ڳ���
		 if(city!=null&&!city.equals("null")){
				hql.append("and c_area ='"+city+"'");
			}
		//Ʒ��
		if(makes!=null&&!makes.equals("null")){
			hql.append(" And brand = '"+makes+"'");
		}
		if(carInfo!=null&&!carInfo.equals("null")){
			hql.append(" And brand = '"+carInfo+"'");
		}
//		if(paixu.equals("�۸�")){
//			hql.append(" order by  price  asc");
//		}
//		else if(paixu.equals("����")){
//			hql.append(" order by  registration  asc");
//		}else if(paixu.equals("���")){
//			hql.append(" order by  kilometre  asc");
//		}
		
		//����
		if(models!=null&&!models.equals("null")){
			hql.append(" And chexing = '"+models+"'");
		}
		
		//�۸�
		if(price!=null&&price.equals("5������")){
			hql.append(" And price < 5");
		}else if(price!=null&&price.equals("5-10��")){
			hql.append(" And price >= 5 And price <=10");
		}else if(price!=null&&price.equals("10-15��")){
			hql.append(" And price >= 10 And price <=15");
		}else if(price!=null&&price.equals("15-20��")){
			hql.append(" And price >= 15 And price <=20");
		}else if(price!=null&&price.equals("20-25��")){
			hql.append(" And price >= 20 And price <=25");
		}
		else if(price!=null&&price.equals("25-40��")){
			hql.append(" And price >= 25 And price <=40");
		}
		else if(price!=null&&price.equals("40-60��")){
			hql.append(" And price >= 40 And price <=60");
		}
		else if(price!=null&&price.equals("60������")){
			hql.append(" And price >= 60");
		}
		//����
		
		if(carage!=null&&carage.equals("1������")){
			hql.append(" And registration>DATE_SUB(CURDATE(), INTERVAL 1 YEAR)");
		}else if(carage!=null&&carage.equals("3������")){
			hql.append(" And registration>DATE_SUB(CURDATE(), INTERVAL 3 YEAR)");
		}else if(carage!=null&&carage.equals("5������")){
			hql.append(" And registration>DATE_SUB(CURDATE(), INTERVAL 5 YEAR)");
		}else if(carage!=null&&carage.equals("5������")){
			hql.append(" And registration<DATE_SUB(CURDATE(), INTERVAL 5 YEAR)");
		}
		//������;
		if(use!=null&&!use.equals("null")){
			hql.append(" And c_use = '"+use+"'");
		}
		//��ʻ���
		if(kilometre!=null&&kilometre.equals("1������")){
			hql.append(" And kilometre <= 1");
		}else if(kilometre!=null&&kilometre.equals("3������")){
			hql.append(" And kilometre >= 1  And kilometre <= 3");
		}else if(kilometre!=null&&kilometre.equals("5������")){
			hql.append(" And kilometre >= 3  And kilometre <= 5");
		}else if(kilometre!=null&&kilometre.equals("5��������")){
			hql.append(" And kilometre > 5");
		}
		
		//������
		if(transmission!=null&&!transmission.equals("null")){
			hql.append(" And  ct_id in(SELECT distinct ct_id FROM cartype where transmission='"+transmission+"')");
		}
		//����
		if(engine!=null&&engine.equals("1.0L����")){
			hql.append(" And ct_id in(SELECT distinct ct_id FROM cartype where engine_capacity<1000)");
		}else if(engine!=null&&engine.equals("1.0-3.0L")){
			hql.append(" And  ct_id in(SELECT distinct ct_id FROM cartype where engine_capacity>=1000 and engine_capacity<=3000)");
		}else if(engine!=null&&engine.equals("3.0-5.0L")){
			hql.append(" And  ct_id in(SELECT distinct ct_id FROM cartype where engine_capacity>=3000 and engine_capacity<=5000)");
		}else if(engine!=null&&engine.equals("5.0-7.0L")){
			hql.append(" And ct_id in(SELECT distinct ct_id FROM cartype where engine_capacity>=5000 and engine_capacity<=7000)");
		}else if(engine!=null&&engine.equals("7.0L����")){
			hql.append(" And ct_id in(SELECT distinct ct_id FROM cartype where engine_capacity>=7000)");
		}
		//����
		if(country!=null&&!country.equals("null")){
			hql.append(" And ct_id in(SELECT distinct ct_id FROM cartype where country='"+country+"')");
		}
		Query query = session.createSQLQuery(hql.toString());
		Iterator its =  query.list().iterator();
		StringBuilder car = new StringBuilder();
		car.append("[");
		while(its.hasNext()){
			Object [] O=((Object [])its.next());
			car.append("{\"brand\":");
			car.append("\"");
			car.append(O[0]);
			car.append("\",\"chexing\":");
			car.append("\"");
			car.append(O[1]);
			car.append("\",\"price\":");
			car.append("\"");
			car.append(O[2]);
			car.append("\",\"image\":");
			car.append("\"");
			car.append(O[3]);
			car.append("\",\"kilometre\":");
			car.append("\"");
			car.append(O[4]);
			car.append("\",\"registration\":");
			car.append("\"");
			car.append(O[5]);
			car.append("\",\"cid\":");
			car.append("\"");
			car.append(O[6]);
			car.append("\"}");
			if(its.hasNext()){
				car.append(",");
			}
		}
		car.append("]");
		System.out.println(car);
	
	   session.close(); 
	   PrintWriter out = response.getWriter();
		out.println(car);
		out.flush();
		return "";
	 }
	
}
