package gxa.service;

import gxa.entity.Car;
import gxa.entity.Users;
import gxa.page.PageInfo;

import java.util.List;

public interface CarServiceI {
	public  List<Car> getAllCar(PageInfo pageInfo)throws Exception ;
	 public Car getCarById(int id)throws Exception;
	 public void update(Car car) throws Exception;
	 public void add(Car car) throws Exception;
	 public Car deleteCarById(int id)throws Exception;
	 public void delete(Car car) throws Exception;
	public List<Car> getAllCar(PageInfo pageInfo, int id) throws Exception;
}
