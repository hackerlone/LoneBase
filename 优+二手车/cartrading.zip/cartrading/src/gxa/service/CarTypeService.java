package gxa.service;

import java.util.List;

import gxa.dao.CarTypeDaoI;
import gxa.entity.Admin;
import gxa.entity.CarType;
import gxa.page.PageInfo;

public class CarTypeService implements CarTypeServiceI {
	private CarTypeDaoI CarTypeDaoI;

	public CarTypeDaoI getCarTypeDaoI() {
		return CarTypeDaoI;
	}

	public void setCarTypeDaoI(CarTypeDaoI CarTypeDaoI) {
		this.CarTypeDaoI = CarTypeDaoI;
	}
	//��ѯ
	public  List<CarType> getAllCarType(PageInfo pageInfo) throws Exception{
		 return CarTypeDaoI.getPage("From CarType", pageInfo);
	}
	//��ID��ѯ��������
		public CarType getCarTypeById(int id) throws Exception{
			return CarTypeDaoI.getCarTypeById(id);
		}
	//���³���������Ϣ
		public void update(CarType cartype) throws Exception{
			CarTypeDaoI.update(cartype);
		}
	//���ӳ���������Ϣ
		public void addCarType(CarType cartype) throws Exception{
			CarTypeDaoI.addCarType(cartype);
		}
}
