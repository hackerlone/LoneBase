package gxa.service;

import gxa.dao.CarDaoI;
import gxa.entity.Car;

import gxa.page.PageInfo;

import java.util.List;

public class CarService implements CarServiceI {
	private CarDaoI carDaoI;

	public CarDaoI getCarDaoI() {
		return carDaoI;
	}

	public void setCarDaoI(CarDaoI carDaoI) {
		this.carDaoI = carDaoI;
	}

	public List<Car> getAllCar(PageInfo pageInfo) throws Exception {
		return carDaoI.getPage("From Car", pageInfo);
	}
	public List<Car> getAllCar(PageInfo pageInfo,int id) throws Exception {
		return carDaoI.getPage("From Car where u_id="+id, pageInfo);
	}
	public Car getCarById(int id) throws Exception {
		return carDaoI.getCarById(id);
	}

	public void update(Car car) throws Exception {
		carDaoI.update(car);
	}
	public void add(Car car) throws Exception{
		carDaoI.add(car);
	}
	public Car deleteCarById(int id) throws Exception {
		return carDaoI.deleteCarById(id);
	}

	public void delete(Car car) throws Exception {
		carDaoI.delete(car);
	}
}
