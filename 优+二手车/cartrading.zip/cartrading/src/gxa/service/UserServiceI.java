package gxa.service;

import gxa.entity.Users;
import gxa.page.PageInfo;

import java.util.List;

public interface UserServiceI {
	public  List<Users> getAllUser(PageInfo pageInfo)throws Exception  ;
	 public Users getUsersById(int id)throws Exception;
	 public void update(Users users) throws Exception;
	 public void add(Users users) throws Exception;
}
