package gxa.service;

import gxa.entity.Admin;

import gxa.page.PageInfo;

import java.util.List;

public interface AdminServiceI {
	public  List<Admin> getAllAdmin(PageInfo pageInfo)throws Exception;
	//��ѯ����
	public Admin getAdminById(int id) throws Exception;
	//�޸�
	public void update(Admin admin) throws Exception;
	//����
	public void addAdmin(Admin admin) throws Exception;
}
