package gxa.service;

import gxa.entity.Admin;
import gxa.entity.CarType;
import gxa.entity.CarType;
import gxa.page.PageInfo;

import java.util.List;

public interface CarTypeServiceI {
	public  List<CarType> getAllCarType(PageInfo pageInfo)throws Exception;
	//��ѯ����
	public CarType getCarTypeById(int id) throws Exception;
	//�޸�
	public void update(CarType cartype) throws Exception;
	//����
	public void addCarType(CarType cartype) throws Exception;
}
