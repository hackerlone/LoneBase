package gxa.entity;
import java.util.List;

/**
 * Users entity. @author MyEclipse Persistence Tools
 */

public class Users implements java.io.Serializable {

	// Fields

	private Integer UId;
	private String UName;
	private String UPwd;
	private String UImg;
	private Integer coin;
	private String UPhone;
	private String UType;
	private String UAdress;
	private String UDisable;
	private List<Car> cars;
	// Constructors

	/** default constructor */
	public Users() {
	}

	/** full constructor */
	public Users(String UName, String UPwd, String UImg,
			Integer coin, String UPhone, String UType, String UAdress,
			String UDisable) {
	
		this.UName = UName;
		this.UPwd = UPwd;
		this.UImg = UImg;
		this.coin = coin;
		this.UPhone = UPhone;
		this.UType = UType;
		this.UAdress = UAdress;
		this.UDisable = UDisable;
		
	}

	// Property accessors

	
	
	public Integer getUId() {
		return this.UId;
	}

	public List<Car> getCars() {
		return cars;
	}

	public void setCars(List<Car> cars) {
		this.cars = cars;
	}

	public void setUId(Integer UId) {
		this.UId = UId;
	}

	public String getUName() {
		return this.UName;
	}

	public void setUName(String UName) {
		this.UName = UName;
	}

	public String getUPwd() {
		return this.UPwd;
	}

	public void setUPwd(String UPwd) {
		this.UPwd = UPwd;
	}

	public String getUImg() {
		return this.UImg;
	}

	public void setUImg(String UImg) {
		this.UImg = UImg;
	}

	public Integer getCoin() {
		return this.coin;
	}

	public void setCoin(Integer coin) {
		this.coin = coin;
	}

	public String getUPhone() {
		return this.UPhone;
	}

	public void setUPhone(String UPhone) {
		this.UPhone = UPhone;
	}

	public String getUType() {
		return this.UType;
	}

	public void setUType(String UType) {
		this.UType = UType;
	}

	public String getUAdress() {
		return this.UAdress;
	}

	public void setUAdress(String UAdress) {
		this.UAdress = UAdress;
	}

	public String getUDisable() {
		return this.UDisable;
	}

	public void setUDisable(String UDisable) {
		this.UDisable = UDisable;
	}

}