package gxa.entity;

/**
 * Cartype entity. @author MyEclipse Persistence Tools
 */

public class CarType implements java.io.Serializable {

	// Fields

	private Integer ctId;
	private String firstLetter;
	private String makeName;
	private String modelSeries;
	private String modelName;
	private String typeSeries;
	private String typeName;
	private String country;
	private String technology;
	private String vehicleClass;
	private Integer engineCapacity;
	private String transmission;
	

	// Constructors

	/** default constructor */
	public CarType() {
	}

	/** minimal constructor */
	public CarType(Integer ctId) {
		this.ctId = ctId;
	}

	/** full constructor */
	public CarType(Integer ctId, String firstLetter, String makeName,
			String modelSeries, String modelName, String typeSeries,
			String typeName, String country, String technology,
			String vehicleClass, Integer engineCapacity, String transmission) {
		this.ctId = ctId;
		this.firstLetter = firstLetter;
		this.makeName = makeName;
		this.modelSeries = modelSeries;
		this.modelName = modelName;
		this.typeSeries = typeSeries;
		this.typeName = typeName;
		this.country = country;
		this.technology = technology;
		this.vehicleClass = vehicleClass;
		this.engineCapacity = engineCapacity;
		this.transmission = transmission;
	}

	// Property accessors

	public Integer getCtId() {
		return this.ctId;
	}

	public void setCtId(Integer ctId) {
		this.ctId = ctId;
	}

	public String getFirstLetter() {
		return this.firstLetter;
	}

	public void setFirstLetter(String firstLetter) {
		this.firstLetter = firstLetter;
	}

	public String getMakeName() {
		return this.makeName;
	}

	public void setMakeName(String makeName) {
		this.makeName = makeName;
	}

	public String getModelSeries() {
		return this.modelSeries;
	}

	public void setModelSeries(String modelSeries) {
		this.modelSeries = modelSeries;
	}

	public String getModelName() {
		return this.modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getTypeSeries() {
		return this.typeSeries;
	}

	public void setTypeSeries(String typeSeries) {
		this.typeSeries = typeSeries;
	}

	public String getTypeName() {
		return this.typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getTechnology() {
		return this.technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getVehicleClass() {
		return this.vehicleClass;
	}

	public void setVehicleClass(String vehicleClass) {
		this.vehicleClass = vehicleClass;
	}

	public Integer getEngineCapacity() {
		return this.engineCapacity;
	}

	public void setEngineCapacity(Integer engineCapacity) {
		this.engineCapacity = engineCapacity;
	}

	public String getTransmission() {
		return this.transmission;
	}

	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}

}