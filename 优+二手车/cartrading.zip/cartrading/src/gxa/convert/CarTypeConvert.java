package gxa.convert;

import gxa.entity.CarType;

import java.util.Map;

import org.apache.struts2.util.StrutsTypeConverter;

public class CarTypeConvert extends StrutsTypeConverter {

	public Object convertFromString(Map context, String[] values, Class class1) {
		// TODO Auto-generated method stub
		CarType cartype = new CarType();
		cartype.setCtId(Integer.parseInt(values[0]));
		return cartype;
	}

	@Override
	public String convertToString(Map context, Object obj) {
         return "";
	}



}
